"""Paired memory interventions inspired by Cloos et al., arXiv:2610.07130.

This evaluates continuation behaviour, not task mastery or consciousness.
Private checkpoints stay local; the returned report contains aggregates only.
"""
import copy
from collections import Counter
from tempfile import TemporaryDirectory

from .engine import World, digest
from .memory import CATEGORIES, ensure, EXPERIMENT_ACTIONS


def non_memory_digest(world):
    state = world.state()
    for agent in state["agents"].values():
        agent.pop("ltm", None)
    return digest(state)


def compare_memories(world, ticks=24, backend_factory=None):
    """Fork an explored world. Only structured LTM changes at the boundary.

    Tasks, short-term memories, writings, scheduler and physical state are held
    fixed. They can still carry knowledge: this is not complete forgetting.
    Backend factories must return fresh, identically configured backends.
    """
    if type(ticks) is not int or not 1 <= ticks <= 10000:
        raise ValueError("ticks must be an integer from 1 to 10000")
    if backend_factory is None:
        from .engine import MockInferenceBackend
        if not isinstance(world.backend, MockInferenceBackend):
            raise ValueError("a fresh backend factory is required for non-mock worlds")
    source = non_memory_digest(world)
    report = {"schema": 1, "paper": "https://arxiv.org/abs/2610.07130",
              "classification": "mock-or-test", "model_id": world.manifest["model_id"],
              "model_revision": world.manifest["model_revision"], "seed": world.seed,
              "start_tick": world.tick, "requested_ticks": ticks,
              "source_digest": digest(world.state()), "branches": [],
              "interpretation": "Continuation comparison only; no task-success or learning claim. "
              "Short-term history, intentions and public writings are retained in every branch."}
    with TemporaryDirectory(prefix="caitanya-learning-") as directory:
        checkpoint = world.checkpoint(directory)
        for condition in ("retained", "procedural_removed", "structured_memory_removed"):
            branch = World.restore(checkpoint, backend=backend_factory() if backend_factory else None)
            removed = 0
            for agent in branch.agents.values():
                ltm = ensure(agent)
                if condition == "procedural_removed":
                    removed += len(ltm["procedural"])
                    ltm["procedural"] = []
                elif condition == "structured_memory_removed":
                    removed += sum(len(ltm[key]) for key in CATEGORIES)
                    removed += len(ltm["relationships"]) + len(ltm["places"]) + len(ltm["recent_ops"])
                    agent.ltm = {}
            if non_memory_digest(branch) != source:
                raise ValueError("memory intervention changed non-memory state")
            # Make journal deltas start from the actual intervened state.
            branch._last_committed_state = copy.deepcopy(branch.state())
            offset, rejected = len(branch.events), len(branch.rejections)
            for _ in range(ticks):
                branch.step()
            events = branch.events[offset:]
            actions = [e for e in events if e["source"] == "validated_action"]
            counts = Counter(e["type"] for e in actions)
            report["branches"].append({
                "condition": condition, "removed_entries": removed,
                "same_non_memory_start": True, "completed_ticks": branch.tick - world.tick,
                "validated_actions": len(actions), "rejected_actions": len(branch.rejections) - rejected,
                "experiment_actions": sum(n for action, n in counts.items() if action.upper() in EXPERIMENT_ACTIONS),
                "failed_decisions": sum(e["type"] == "inference_failed" for e in events),
                "living": sum(a.alive for a in branch.agents.values()),
                "action_counts": dict(counts),
            })
    if world.manifest["model_id"] == "LiquidAI/LFM3-1.7B":
        report["classification"] = "model-continuation-comparison"
    return report
